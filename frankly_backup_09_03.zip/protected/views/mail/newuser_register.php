<div style="font:12px Arial, Helvetica, sans-serif">
   <h2> Hi <?php echo $sendTo; ?>, </h2>
   <p>New user has been registered. Here details:</p>
   <p> 
      Name : <?php echo $register_user['name']; ?> <br/>
      Email : <?php echo $register_user['email']; ?> <br/>
      Phone Number : <?php echo $register_user['phone_num']; ?> <br/>
      Grade : <?php echo $register_user['grade']; ?> <br/>
      Course : <?php echo $register_user['course']; ?> <br/>
      School : <?php echo $register_user['school']; ?> <br/>
      Teacher : <?php echo $register_user['teacher_name']; ?> <br/>
      Hear about the site : <?php echo $register_user['how_hear']; ?> <br/>
   </p>
   <br/>
   <p>Thanks,</p>
   <p>Frankly Math</p>
</div>