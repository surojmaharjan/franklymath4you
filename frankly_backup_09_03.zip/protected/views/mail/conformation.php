<div style="font:12px Arial, Helvetica, sans-serif">
   <h2> Hi <?php echo $register_user['name'] ?>, </h2>
   <p>Your Payment for frankly math completed.</p>
   
   <br/>
   <p>Thanks,</p>
   <p>Frankly Math</p>
</div>