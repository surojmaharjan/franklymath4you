<div style="font:12px Arial, Helvetica, sans-serif">
   <h2> Hi <?php echo $register_user['name'] ?>, </h2>
   <p>Thank you for registering to frankly math.</p>
   
   <br/>
   <p>Thanks,</p>
   <p>Frankly Math</p>
</div>