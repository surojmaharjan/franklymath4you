<div style="background:#dddddd; padding:2em; font:10px Arial, Helvetica, sans-serif; color:#888">
    <div style="background:#ffffff; padding:1.5em; font:12px Arial, Helvetica, sans-serif; color:#333">
        <?php echo $content;?>
    </div>
</div>
