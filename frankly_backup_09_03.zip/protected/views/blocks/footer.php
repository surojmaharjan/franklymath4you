<div class="footer-wrapper">
   <div class="footer">
      <div class="footer-left"><ul class="footer-menu">
            <li class="first active"><a href="<?php echo Yii::app()->request->baseUrl.'/home'?>">Home</a></li>
            <li><a href="<?php echo Yii::app()->request->baseUrl.'/howitworks'?>">How It Works</a></li>
            <li><a href="<?php echo Yii::app()->request->baseUrl . '/getstarted' ?>">Get Started</a></li>
            <li><a href="<?php echo Yii::app()->request->baseUrl.'/whoisthisfor'?>">Who Is This For</a></li>
            <li><a href="<?php echo Yii::app()->request->baseUrl.'/whychoosethismethod'?>">Why Choose This Method</a></li>
            <li class="last"><a href="<?php echo Yii::app()->request->baseUrl.'/aboutme'?>">About Me</a></li>
         </ul>
         <span class="copyright">Copyright 2013 All Rights Reserved.</span>

      </div>
      <div class="footer-right">
         <div class="footer-right-content"><span>Contact us</span>
            <span style="display: block; font-size: 12px; margin-bottom: 10px; color: #F35723; font-family: Arial,Helvetica,sans-serif;">franklymath4you@gmail.com</span>
            <span class="phone"><span>(914)</span> 806-3820</span></div>
      </div>
   </div>

   <!-- end footer --> 
</div>