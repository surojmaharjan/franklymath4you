<?php
$this->breadcrumbs=array(
	'Paypa'=>array('/paypal'),
	'Confirm',
);
?>

<div>
	<h3>Payment Confirmation</h3>
	<p>
		Payment completed successfully
	</p>
</div>